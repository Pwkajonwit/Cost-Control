import { ProjectDetailClient } from "@/components/dashboards/ProjectDetailClient";
import { isCommittedBill, isPaidBill } from "@/lib/bill-status";
import { TABLES } from "@/lib/config";
import { toNumber } from "@/lib/numbers";
import { getRows } from "@/lib/db";
import { getCategoryExpense, hydrateProjectSummary, rowsForProject, valueOf } from "@/lib/project-summary";
import type { SheetRow } from "@/lib/types";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";
export const revalidate = 0;

type ProjectDetailPageProps = {
  params: Promise<{ projectId: string }>;
};

const DETAIL_FIELDS = [
  "ID Project",
  "ชื่อ Project",
  "ชื่อลูกค้า",
  "สถานที่",
  "บริษัท",
  "รับผิดชอบ",
  "วันที่",
  "color",
  "คุมงบประเภทงาน",
  "ยอดงาน",
  "ยอดรวม vat",
  "งบไม่เกิน",
  "รวม ALL"
];

const RELATED_COLUMNS = [
  "ลำดับ",
  "ว/ด/ป",
  "ร้าน/บุคคล",
  "สินค้า/ทำงาน",
  "บิล",
  "ประเภท",
  "ยอดเงิน",
  "ยอดโอน",
  "ผู้เบิก",
  "สถานะ"
];

const EXPENSE_CATEGORIES = [
  "ค่าของ",
  "ค่าแรง",
  "พนักงาน",
  "น้ำมัน",
  "ซ่อมรถ",
  "เครื่องจักร",
  "เครื่องมือ",
  "อื่นๆ"
];

export default async function ProjectDetailPage({ params }: ProjectDetailPageProps) {
  const { projectId } = await params;
  const decodedProjectId = decodeURIComponent(projectId);

  const [projectRows, dataRows, customerRows, companyRows, peopleRows] = await Promise.all([
    getRows(TABLES.PROJECT).catch(() => []),
    getRows(TABLES.DATA).catch(() => []),
    getRows(TABLES.CUSTOMER).catch(() => []),
    getRows(TABLES.COMPANY).catch(() => []),
    getRows(TABLES.PEOPLE).catch(() => []),
  ]);

  const project = projectRows.find((row) => String(row["ID Project"] || "").trim() === decodedProjectId.trim());
  if (!project) notFound();

  const relatedRows = rowsForProject(dataRows, project["ID Project"]);
  const summaryRows = relatedRows.filter(isCommittedBill).map((row) => ({
    ...row,
    "ผู้เบิก": resolveRequesterName(row["ผู้เบิก"], peopleRows)
  }));
  const { project: hydratedProject, totals } = hydrateProjectSummary(project, relatedRows);
  const paidRows = summaryRows.filter(isPaidBill);
  const pendingRows = summaryRows.filter((r) => !isPaidBill(r));
  const expenseBreakdown = buildExpenseBreakdown(paidRows);
  const pendingBreakdown = buildExpenseBreakdown(pendingRows);

  const projectName = displayValue(valueOf(hydratedProject, ["ชื่อ Project"])) || `Project ${decodedProjectId}`;

  // Build Customer Display - Name only
  const rawCusId = String(hydratedProject["ชื่อลูกค้า"] || hydratedProject["ลูกค้า"] || "").trim();
  const matchedCus = customerRows.find(
    (c) => String(c["id_cus"] || c["id"] || c["รหัสลูกค้า"] || "").trim().toLowerCase() === rawCusId.toLowerCase()
  );
  const cusName = matchedCus
    ? String(matchedCus["ชื่อลูกค้า"] || matchedCus["ชื่อบริษัท"] || matchedCus["ชื่อ-นามสกุล"] || "").trim()
    : "";
  const customerDisplay = cusName || rawCusId || "-";

  // Build Company Display - Name only
  const rawCompId = String(hydratedProject["บริษัท"] || hydratedProject["บริษัทรับงาน"] || "").trim();
  const matchedComp = companyRows.find(
    (c) => String(c["id_Company"] || c["id"] || c["รหัสบริษัท"] || "").trim().toLowerCase() === rawCompId.toLowerCase()
  );
  const compName = matchedComp
    ? String(matchedComp["ชื่อบริษัท"] || matchedComp["ชื่อย่อ"] || "").trim()
    : "";
  const companyDisplay = compName || rawCompId || "-";

  return (
    <ProjectDetailClient
      projectId={decodedProjectId}
      projectName={projectName}
      hydratedProject={hydratedProject}
      customerDisplay={customerDisplay}
      companyDisplay={companyDisplay}
      totals={totals}
      summaryRows={summaryRows}
      expenseBreakdown={expenseBreakdown}
      pendingBreakdown={pendingBreakdown}
      detailFields={DETAIL_FIELDS}
      relatedColumns={RELATED_COLUMNS}
      expenseCategories={EXPENSE_CATEGORIES}
    />
  );
}

function resolveRequesterName(rawRequester: unknown, peopleRows: SheetRow[]): string {
  const str = String(rawRequester || "").trim();
  if (!str) return "-";

  const strClean = str.toLowerCase().replace(/^pt/i, "").trim();

  const found = peopleRows.find((p) => {
    const pId = String(p["รหัสพนักงาน"] || p["id"] || "").trim().toLowerCase();
    const pIdClean = pId.replace(/^pt/i, "").trim();
    const pPhone = String(p["เบอร์โทร"] || p["เบอร์โทรศัพท์"] || p["phone"] || "").trim();
    const pNickname = String(p["ชื่อเล่น"] || "").trim().toLowerCase();
    const pFullName = String(p["ชื่อ-นามสกุล"] || "").trim().toLowerCase();

    return (
      pId === str.toLowerCase() ||
      (pIdClean && pIdClean === strClean) ||
      (pPhone && pPhone === str) ||
      (pNickname && pNickname === str.toLowerCase()) ||
      (pFullName && pFullName === str.toLowerCase())
    );
  });

  if (found) {
    const nickname = String(found["ชื่อเล่น"] || "").trim();
    const fullName = String(found["ชื่อ-นามสกุล"] || found["name"] || "").trim();
    return nickname || fullName || str;
  }

  return str;
}

function buildExpenseBreakdown(summaryRows: SheetRow[]) {
  const breakdown: Record<string, number> = {};
  for (const cat of EXPENSE_CATEGORIES) {
    breakdown[cat] = getCategoryExpense(summaryRows, cat);
  }
  return breakdown;
}

function displayValue(value: unknown) {
  if (value === null || value === undefined) return "";
  return String(value);
}
